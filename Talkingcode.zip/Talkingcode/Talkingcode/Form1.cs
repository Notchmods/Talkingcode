﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Speech.Synthesis;

namespace Talkingcode
{
    public partial class Form1 : Form
    {
        SpeechSynthesizer Talk = new SpeechSynthesizer();
        public Form1()
        {
            InitializeComponent();
            Talk.Speak("hey guys what is up it is yo boy Kovalev here");
        }
    }
}
